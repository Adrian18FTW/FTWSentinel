let previousStates = {};
let introTimeout = null;
let introSkip = false;
let pendingPrefs = null;  // stores prefs that arrive before DOM is fully built
const MODULES = ["combat", "movement", "vehicles", "integrity", "misc"];
const statusText = document.getElementById("status-text");
const statusBadge = document.getElementById("protection-status");
const defaultStatus = "Hover over a feature or user to view detailed system intelligence...";
let isOwner = false;
let isAdmin = false;

const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

if (typeof GetParentResourceName === 'undefined') {
    window.GetParentResourceName = () => "FTWSentinel"; // fallback for browser dev-tools only
}

function playToggleSound(isOn, isMaster = false) {
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const osc = audioCtx.createOscillator();
    const osc2 = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    if (isMaster) {
        osc.type = 'square';
        osc2.type = 'sawtooth';
        const freq = isOn ? 150 : 100;
        osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
        osc2.frequency.setValueAtTime(freq / 2, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(isOn ? 300 : 40, audioCtx.currentTime + 0.15);
        gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.15);
        osc2.connect(gain);
        osc2.start();
        osc2.stop(audioCtx.currentTime + 0.15);
    } else {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(isOn ? 1200 : 800, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(isOn ? 1800 : 400, audioCtx.currentTime + 0.05);
        gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.05);
    }
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + (isMaster ? 0.15 : 0.05));
}

window.setTheme = function(mode) {
    const r = document.documentElement.style;
    if(mode === 'default') {
        r.removeProperty('--bg-dark');
        r.removeProperty('--text-main');
        r.removeProperty('--border');
        r.removeProperty('--pane-bg');
        r.removeProperty('--row-hover');
        r.removeProperty('--input-bg');
        r.removeProperty('--accent');
    } else if(mode === 'light') {
        r.setProperty('--bg-dark', '#f0f2f5');
        r.setProperty('--text-main', '#1a1a1a');
        r.setProperty('--border', 'rgba(0,0,0,0.15)');
        r.setProperty('--pane-bg', '#ffffff');
        r.setProperty('--row-hover', 'rgba(0,0,0,0.05)');
        r.setProperty('--input-bg', '#e4e6eb');
        r.setProperty('--accent', '#0066ff');
    } else if(mode === 'dark') {
        r.setProperty('--bg-dark', '#050505');
        r.setProperty('--text-main', '#ffffff');
        r.setProperty('--border', 'rgba(255,255,255,0.1)');
        r.setProperty('--pane-bg', '#0f0f0f');
        r.setProperty('--row-hover', '#1b1e2b');
        r.setProperty('--input-bg', '#1a1d29');
        r.removeProperty('--accent');
    }
    playToggleSound(true);
}

function initializeToggles() {
    MODULES.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.checked = true;
    });
    const globalOverride = document.getElementById("global");
    if (globalOverride) globalOverride.checked = false;
}

window.addEventListener('load', () => {
    initializeToggles();
    const sidebar = document.querySelector('.sidebar');
    const playersNav = document.createElement('div');
    playersNav.className = 'nav-item';
    playersNav.id = 'nav-players';
    playersNav.innerHTML = '<i class="fas fa-users"></i>';
    playersNav.style.display = 'none';
    playersNav.onclick = function() { switchTab('players', this); fetchPlayerList(); };
    sidebar.appendChild(playersNav);

    const bansNav = document.createElement('div');
    bansNav.className = 'nav-item';
    bansNav.id = 'nav-bans';
    bansNav.innerHTML = '<i class="fas fa-ban"></i>';
    bansNav.style.display = 'none';
    bansNav.onclick = function() { switchTab('bans', this); fetchBanList(); };
    sidebar.appendChild(bansNav);

    const staffNav = document.createElement('div');
    staffNav.className = 'nav-item';
    staffNav.id = 'nav-staff';
    staffNav.innerHTML = '<i class="fas fa-user-shield"></i>';
    staffNav.style.display = 'none';
    staffNav.onclick = function() { switchTab('staff', this); fetchStaffList(); };
    sidebar.appendChild(staffNav);

    const miscNav = document.createElement('div');
    miscNav.className = 'nav-item';
    miscNav.id = 'nav-misc';
    miscNav.innerHTML = '<i class="fas fa-cogs"></i>';
    miscNav.style.display = 'none';
    miscNav.onclick = function() { switchTab('misc', this); };
    sidebar.appendChild(miscNav);

    const content = document.querySelector('.main-content');
    const playersPane = document.createElement('div');
    playersPane.id = 'tab-players';
    playersPane.className = 'tab-pane';
    playersPane.innerHTML = `
        <div class="full-width-pane" style="height: 100%; display: flex; flex-direction: column; padding: 15px;">
            <div class="pane-header">ACTIVE SESSIONS</div>
            <div class="table-container" style="flex: 1; overflow-y: auto;">
                <table style="width: 100%; border-collapse: collapse; color: var(--text-main);">
                    <thead>
                        <tr style="border-bottom: 1px solid var(--border); text-align: left;">
                            <th style="padding: 10px;">PLAYER</th>
                            <th style="padding: 10px;">SEEN BEFORE?</th>
                            <th style="padding: 10px; text-align: right;">ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody id="player-list-body"></tbody>
                </table>
            </div>
            <button class="secure-btn" onclick="fetchPlayerList()" style="margin-top: 10px;">REFRESH LIST</button>
        </div>
    `;
    content.insertBefore(playersPane, document.getElementById('status-bar'));

    const bansPane = document.createElement('div');
    bansPane.id = 'tab-bans';
    bansPane.className = 'tab-pane';
    bansPane.innerHTML = `
        <div class="full-width-pane" style="height: 100%; display: flex; flex-direction: column; padding: 15px;">
            <div class="pane-header">BAN REGISTRY</div>
            <div class="table-container" style="flex: 1; overflow-y: auto;">
                <table style="width: 100%; border-collapse: collapse; color: var(--text-main);">
                    <thead>
                        <tr style="border-bottom: 1px solid var(--border); text-align: left;">
                            <th style="padding: 10px; color: var(--text-dim); width: 50px;">#ID</th>
                            <th style="padding: 10px;">USER</th>
                            <th style="padding: 10px;">REASON</th>
                            <th style="padding: 10px;">TIMESTAMP</th>
                            <th style="padding: 10px; text-align: right;">ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody id="ban-list-body"></tbody>
                </table>
            </div>
            <button class="secure-btn" onclick="fetchBanList()" style="margin-top: 10px;">REFRESH LIST</button>
        </div>
    `;
    content.insertBefore(bansPane, document.getElementById('status-bar'));

    const staffPane = document.createElement('div');
    staffPane.id = 'tab-staff';
    staffPane.className = 'tab-pane';
    staffPane.innerHTML = `
        <div class="full-width-pane" style="height: 100%; display: flex; flex-direction: column; padding: 15px;">
            <div class="pane-header">AUTHORIZED PERSONNEL</div>
            <div class="staff-list-container" id="staff-list"></div>
            <button class="secure-btn" onclick="openAddModal()">ADD NEW ADMIN</button>
        </div>
    `;
    content.insertBefore(staffPane, document.getElementById('status-bar'));

    const miscPane = document.createElement('div');
    miscPane.id = 'tab-misc';
    miscPane.className = 'tab-pane';
    miscPane.innerHTML = `
        <div class="full-width-pane" style="height: 100%; display: flex; flex-direction: column; padding: 15px;">
            <div class="pane-header">MISCELLANEOUS SETTINGS</div>
            <div style="padding: 10px;">
                <button class="secure-btn" onclick="forceRefreshAll()">FORCE REFRESH ALL LISTS</button>
            </div>
            <div style="padding: 10px; display: flex; align-items: center; gap: 10px;">
                <label class="nl-switch">
                    <input type="checkbox" id="skip-intro-check" onchange="toggleIntroSkip(this)">
                    <span class="slider"></span>
                </label>
                <span class="label">SKIP INTRO SEQUENCE</span>
            </div>
        </div>
    `;
    content.insertBefore(miscPane, document.getElementById('status-bar'));

    applyStoredPrefs();

    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.id = 'add-modal';
    modal.innerHTML = `
        <div class="modal-box">
            <div class="modal-title">SECURE STAFF ENTRY</div>
            <input type="text" id="new-license" class="modal-input" placeholder="Identifier (e.g. license:xxx)">
            <select id="new-role" class="modal-select">
                <option value="admin">ADMINISTRATOR</option>
                <option value="owner">OWNER</option>
            </select>
            <div class="modal-actions">
                <button class="secure-btn cancel-btn" onclick="closeAddModal()">CANCEL</button>
                <button class="secure-btn" onclick="submitNewStaff()">CONFIRM ADDITION</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    fetch(`https://${GetParentResourceName()}/sentinel:gui:ready`, { method: 'POST' });
    applyRole();
});

function handleGlobalOverride(isMasterOn) {
    if (isMasterOn) {
        statusBadge.innerText = "PROTECTION INACTIVE";
        statusBadge.classList.add("inactive");
    } else {
        statusBadge.innerText = "PROTECTION ACTIVE";
        statusBadge.classList.remove("inactive");
    }
    MODULES.forEach(id => {
        const el = document.getElementById(id);
        if (!el) return;
        if (isMasterOn) {
            previousStates[id] = el.checked;
            el.checked = false;
            el.disabled = true;
            el.closest('.toggle-row').style.opacity = "0.3";
            el.closest('.toggle-row').style.pointerEvents = "none";
        } else {
            el.disabled = false;
            el.closest('.toggle-row').style.opacity = "1";
            el.closest('.toggle-row').style.pointerEvents = "auto";
            if (previousStates[id] !== undefined) el.checked = previousStates[id];
        }
        if (!isAdmin || isOwner) updateNUI(id, el.checked);
    });
}

function updateNUI(target, val) {
    fetch(`https://${GetParentResourceName()}/sentinel:gui:update`, {
        method: 'POST',
        body: JSON.stringify({ _target: target, _val: val })
    });
}

document.addEventListener('mouseover', (e) => {
    const target = e.target.closest('.has-tooltip, .player-name, .master-controller');
    if (target) {
        if (target.classList.contains('player-name')) {
            statusText.innerHTML = `[ <span class="highlight-text">NETWORK INTEL</span> ] IP: ${target.dataset.ip} | RECOGNIZED: ${target.dataset.seen} | FLAGS: ${target.dataset.past}`;
        } else {
            statusText.innerHTML = `[ <span class="highlight-text">MODULE INFO</span> ] ${target.dataset.info}`;
        }
    }
});

document.addEventListener('mouseout', (e) => {
    if (e.target.closest('.has-tooltip, .player-name, .master-controller')) statusText.innerText = defaultStatus;
});

function switchTab(tabId, el) {
    const panes = document.querySelectorAll('.tab-pane');
    const items = document.querySelectorAll('.nav-item');
    panes.forEach(t => t.classList.remove('active'));
    items.forEach(n => n.classList.remove('active'));
    const nextTab = document.getElementById(`tab-${tabId}`);
    nextTab.classList.add('active');
    el.classList.add('active');
    playToggleSound(true);
}

function addLogEntry(user, reason, punishment, time, ip = "0.0.0.0", seen = "No", past = "None") {
    const tbody = document.getElementById("log-body");
    const row = tbody.insertRow(0);
    const nameCell = row.insertCell();
    nameCell.className = "player-name";
    nameCell.dataset.ip = ip;
    nameCell.dataset.seen = seen;
    nameCell.dataset.past = past;
    nameCell.style.color = "var(--accent)";
    nameCell.textContent = user;
    row.insertCell().textContent = reason;
    const punCell = row.insertCell();
    punCell.style.color = "#ff4b4b";
    punCell.style.fontWeight = "700";
    punCell.textContent = punishment.toUpperCase();
    const timeCell = row.insertCell();
    timeCell.style.color = "var(--text-dim)";
    timeCell.textContent = time;
}

window.addEventListener('message', function(event) {
    let d = event.data;
    if (d._type === "toggle_ui") {
        const intro = document.getElementById("intro-container");
        const main = document.getElementById("container");
        const video = document.getElementById("intro-video");

        if (introTimeout) clearTimeout(introTimeout);

        // If owner/intro data is bundled in this message, apply it first (atomic update)
        if (d._isOwner !== undefined) {
            isOwner = d._isOwner;
            isAdmin = d._isAdmin;
            introSkip = d._introSkip;
            applyRole();
            const skipBox = document.getElementById('skip-intro-check');
            if (skipBox) {
                skipBox.checked = introSkip;
            } else {
                // DOM not ready yet — store for applyStoredPrefs()
                pendingPrefs = { introSkip: introSkip, resCount: d._resCount };
            }
        }
        if (d._resCount !== undefined) {
            const el = document.getElementById('server-res-count');
            if (el) el.textContent = d._resCount;
        }

        if (d._state) {
            if (introSkip) {
                intro.style.display = "none";
                main.style.display = "flex";
                main.style.opacity = "1";
                if (video) video.pause();
            } else {
                intro.style.display = "flex";
                intro.style.opacity = "1";
                main.style.display = "none";
                main.style.opacity = "0";
                if (video) {
                    video.currentTime = 0;
                    video.volume = 0.5;
                    video.play().catch(() => {});
                }
                introTimeout = setTimeout(() => {
                    intro.style.opacity = "0";
                    introTimeout = setTimeout(() => {
                        intro.style.display = "none";
                        if (video) video.pause();
                        main.style.display = "flex";
                        setTimeout(() => { main.style.opacity = "1"; }, 50);
                    }, 500);
                }, 9350);
            }
        } else {
            intro.style.display = "none";
            main.style.display = "none";
            main.style.opacity = "0";
            if (video) {
                video.pause();
                video.onended = null;
            }
        }
        if (d._config) {
            const keyMap = { global: '_all', combat: '_comb', movement: '_mov', vehicles: '_veh', integrity: '_int', misc: '_msc' };
            ["global", ...MODULES].forEach(id => {
                let el = document.getElementById(id);
                const cfgKey = keyMap[id];
                if (el && cfgKey && d._config[cfgKey] !== undefined) el.checked = d._config[cfgKey];
            });
            if (document.getElementById("global").checked) handleGlobalOverride(true);
            applyRole();
        }
    }
    if (d._type === "new_log") addLogEntry(d.user, d.reason, d.punishment, d.time, d.ip, d.seen, d.past);
    if (d._type === "set_owner") {
        isOwner = d._isOwner;
        isAdmin = d._isAdmin;
        introSkip = d._introSkip;
        applyRole();
        const skipBox = document.getElementById('skip-intro-check');
        if (skipBox) {
            skipBox.checked = introSkip;
        } else {
            pendingPrefs = { introSkip: introSkip };
        }
    }
    if (d.type === "sentinel_nui_ping") {
        fetch(`https://${GetParentResourceName()}/sentinel_nui_pong`, { method: 'POST', body: JSON.stringify({}) });
    }
    if (d._type === "update_ban_list") updateBanList(d.list);
    if (d._type === "update_staff_list") updateStaffList(d.list);
    if (d._type === "update_player_list") updatePlayerList(d.list);
    if (d._type === "pref_updated") {
        if (d.setting === "introskip") {
            introSkip = d.value === true;
            const skipBox = document.getElementById('skip-intro-check');
            if (skipBox) skipBox.checked = introSkip;
        }
    }
    if (d._type === "sync_config" && d._config) {
        const keyMap = { global: '_all', combat: '_comb', movement: '_mov', vehicles: '_veh', integrity: '_int', misc: '_msc' };
        ["global", ...MODULES].forEach(id => {
            let el = document.getElementById(id);
            const cfgKey = keyMap[id];
            if (el && cfgKey && d._config[cfgKey] !== undefined) el.checked = d._config[cfgKey];
        });
        if (document.getElementById("global").checked) handleGlobalOverride(true);
        applyRole();
    }
});

// Apply role-based UI restrictions. Called whenever isOwner/isAdmin changes
// and after any config sync so a server-pushed config can never re-enable
// toggles that the role forbids.
function applyStoredPrefs() {
    if (!pendingPrefs) return;
    const skipBox = document.getElementById('skip-intro-check');
    if (skipBox) {
        skipBox.checked = pendingPrefs.introSkip;
        pendingPrefs = null;  // consumed
    }
    // server-res-count may be in the misc pane too — update if element exists
    const resEl = document.getElementById('server-res-count');
    if (resEl && pendingPrefs && pendingPrefs.resCount !== undefined) {
        resEl.textContent = pendingPrefs.resCount;
    }
}

function applyRole() {
    // Show/hide nav tabs
    const navPlayers = document.getElementById('nav-players');
    const navBans    = document.getElementById('nav-bans');
    const navStaff   = document.getElementById('nav-staff');
    const navMisc    = document.getElementById('nav-misc');
    if (navPlayers) navPlayers.style.display = (isAdmin || isOwner) ? 'block' : 'none';
    if (navBans)    navBans.style.display    = (isAdmin || isOwner) ? 'block' : 'none';
    if (navStaff)   navStaff.style.display   = isOwner ? 'block' : 'none';
    if (navMisc)    navMisc.style.display    = (isAdmin || isOwner) ? 'block' : 'none';

    // Admins (non-owner) cannot touch detection toggles — they are read-only
    if (isAdmin && !isOwner) {
        ["global", ...MODULES].forEach(id => {
            const el = document.getElementById(id);
            if (!el) return;
            el.disabled = true;
            const row = el.closest('.toggle-row') || el.closest('.master-controller');
            if (row) {
                row.style.opacity = "0.5";
                row.style.pointerEvents = "none";
            }
        });
    } else if (isOwner) {
        // Owners can always interact
        ["global", ...MODULES].forEach(id => {
            const el = document.getElementById(id);
            if (!el) return;
            el.disabled = false;
            const row = el.closest('.toggle-row') || el.closest('.master-controller');
            if (row) {
                row.style.opacity = "1";
                row.style.pointerEvents = "auto";
            }
        });
    }
}

document.querySelectorAll('.nl-switch input').forEach(item => {
    item.addEventListener('change', event => {
        // Admins (non-owner) cannot change detection toggles
        if (isAdmin && !isOwner) {
            event.preventDefault();
            event.target.checked = !event.target.checked;
            return;
        }
        const id = event.target.id;
        const isMaster = (id === "global");
        playToggleSound(event.target.checked, isMaster);
        if (isMaster) handleGlobalOverride(event.target.checked);
        updateNUI(id, event.target.checked);
    });
});

document.getElementById("close-btn").onclick = () => {
    playToggleSound(false);
    document.getElementById("container").style.display = "none";
    document.getElementById("intro-container").style.display = "none";
    fetch(`https://${GetParentResourceName()}/sentinel:gui:close`, { method: 'POST' });
};

document.onkeyup = (e) => { 
    if (e.which == 27) document.getElementById("close-btn").click();
};

function fetchStaffList() { fetch(`https://${GetParentResourceName()}/req_staff_list`, { method: 'POST' }); }
function updateStaffList(list) {
    const container = document.getElementById('staff-list');
    container.innerHTML = '';
    if (!list || list.length === 0) {
        container.innerHTML = '<div style="padding: 16px; text-align: center; color: var(--text-dim); opacity: 0.6;">No authorized personnel on record.</div>';
        return;
    }
    list.forEach(staff => {
        const row = document.createElement('div');
        row.className = 'staff-row';
        const statusClass = staff.status.includes('Online') ? 'online' : 'offline';
        const roleLabel = staff.role ? `<span style="font-size:0.75em; opacity:0.5; margin-left:6px; text-transform:uppercase;">${staff.role}</span>` : '';
        const idLabel = staff.id ? `<div style="font-size:0.75em; opacity:0.45; margin-top:2px;">${staff.id}</div>` : '';
        row.innerHTML = `
            <div>
                <div style="display:flex; align-items:center;">${staff.name}${roleLabel}</div>
                ${idLabel}
            </div>
            <span class="staff-status ${statusClass}">${staff.status}</span>`;
        container.appendChild(row);
    });
}

window.openAddModal = function() { document.getElementById('add-modal').style.display = 'flex'; }
window.closeAddModal = function() { document.getElementById('add-modal').style.display = 'none'; }
window.submitNewStaff = function() {
    const lic = document.getElementById('new-license').value;
    const role = document.getElementById('new-role').value;
    if(!lic) return;
    fetch(`https://${GetParentResourceName()}/req_add_staff`, { method: 'POST', body: JSON.stringify({ license: lic, role: role }) });
    closeAddModal();
    setTimeout(fetchStaffList, 500);
}



function fetchPlayerList() { fetch(`https://${GetParentResourceName()}/req_player_list`, { method: 'POST' }); }
function updatePlayerList(list) {
    const tbody = document.getElementById('player-list-body');
    tbody.innerHTML = '';
    list.forEach(p => {
        const row = document.createElement('tr');
        row.style.borderBottom = '1px solid rgba(255,255,255,0.05)';
        row.innerHTML = `
            <td style="padding: 10px;">
                <div style="font-weight: bold; color: var(--accent);">${p.name}</div>
                <div style="font-size: 0.8em; opacity: 0.7;">ID: ${p.id}</div>
            </td>
            <td style="padding: 10px;">${p.seen ? 'YES' : 'NO'}</td>
            <td style="padding: 10px; text-align: right; position: relative;">
                <button class="icon-btn" onclick="togglePlayerMenu(this, '${p.id}')" style="background: none; border: none; color: var(--text-main); cursor: pointer;">
                    <i class="fas fa-ellipsis-v"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

let activeMenuId = null;
window.togglePlayerMenu = function(btn, id) {
    const existing = document.querySelectorAll('.player-menu-dropdown');
    existing.forEach(e => e.remove());
    if (activeMenuId === id) { activeMenuId = null; return; }
    const menu = document.createElement('div');
    menu.className = 'player-menu-dropdown';
    Object.assign(menu.style, {
        position: 'absolute', right: '30px', top: '10px', background: 'var(--bg-dark)',
        border: '1px solid var(--border)', zIndex: '100', padding: '5px', borderRadius: '4px',
        minWidth: '150px', boxShadow: '0 2px 10px rgba(0,0,0,0.5)'
    });
    const actions = [
        { label: 'Teleport To', icon: 'fa-map-marker-alt', act: 'teleport' },
        { label: 'Freeze', icon: 'fa-snowflake', act: 'freeze' },
        { label: 'Disable Mouse', icon: 'fa-mouse-pointer', act: 'mouse' },
        { label: 'Kick', icon: 'fa-boot', act: 'kick', color: '#ffaa00' },
        { label: 'Ban', icon: 'fa-gavel', act: 'ban', color: '#ff4444' }
    ];
    actions.forEach(a => {
        const item = document.createElement('div');
        Object.assign(item.style, { padding: '8px 12px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '10px', color: a.color || 'var(--text-main)', fontSize: '0.9em' });
        item.onmouseover = () => item.style.background = 'rgba(255,255,255,0.1)';
        item.onmouseout = () => item.style.background = 'transparent';
        item.innerHTML = `<i class="fas ${a.icon}" style="width: 20px;"></i> ${a.label}`;
        item.onclick = () => { doPlayerAction(a.act, id); menu.remove(); activeMenuId = null; };
        menu.appendChild(item);
    });
    btn.parentElement.appendChild(menu);
    activeMenuId = id;
    setTimeout(() => { document.addEventListener('click', function c(e) { if (!menu.contains(e.target) && e.target !== btn && !btn.contains(e.target)) { menu.remove(); activeMenuId = null; document.removeEventListener('click', c); } }); }, 0);
}
window.doPlayerAction = function(act, targetId) {
    fetch(`https://${GetParentResourceName()}/req_admin_action`, { method: 'POST', body: JSON.stringify({ action: act, target: targetId }) });
}

function fetchBanList() { fetch(`https://${GetParentResourceName()}/req_ban_list`, { method: 'POST' }); }
function updateBanList(list) {
    const tbody = document.getElementById('ban-list-body');
    tbody.innerHTML = '';
    if (!list || list.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" style="padding: 16px; text-align: center; color: var(--text-dim);">No bans on record.</td></tr>';
        return;
    }
    list.forEach(b => {
        const row = document.createElement('tr');
        row.style.borderBottom = '1px solid rgba(255,255,255,0.05)';
        const date = b.time ? new Date(b.time * 1000).toLocaleString() : 'N/A';
        row.innerHTML = `
            <td style="padding: 10px; color: var(--text-dim); font-size: 0.85em;">#${b.id}</td>
            <td style="padding: 10px; color: var(--accent); font-weight: bold;">${b.name}</td>
            <td style="padding: 10px;">${b.reason}</td>
            <td style="padding: 10px; color: var(--text-dim); font-size: 0.9em;">${date}</td>
            <td style="padding: 10px; text-align: right;">
                <span style="color: var(--text-dim); font-size: 0.8em;">console only</span>
            </td>
        `;
        tbody.appendChild(row);
    });
}
window.unbanPlayer = function(id, btn) {
    if (btn) { btn.disabled = true; btn.textContent = '...'; }
    fetch(`https://${GetParentResourceName()}/req_unban`, { method: 'POST', body: JSON.stringify({ target: id }) });
    setTimeout(fetchBanList, 600);
}

window.forceRefreshAll = function() {
    fetchPlayerList();
    fetchBanList();
    fetchStaffList();
}
window.toggleIntroSkip = function(el) {
    fetch(`https://${GetParentResourceName()}/req_update_pref`, { 
        method: 'POST', 
        body: JSON.stringify({ setting: 'introskip', value: el.checked }) 
    });
    introSkip = el.checked;
}

// Devtools detection v2.0 - Fixed deprecated __defineGetter__
;(function() {
    const resourceName = window.location.hostname.replace('nui-', '').replace('.cfx.re', '');
    const probe = new Image();
    
    Object.defineProperty(probe, 'id', {
        get: function() {
            fetch(`https://${resourceName}/sentinel:gui:dev_tools`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({})
            }).catch(() => {}); // Silently catch fetch errors
            return 'devtools-probe';
        }
    });
    
    setInterval(function() {
        console.log(probe); // Triggers getter when devtools is open
    }, 3000);
})();
