fx_version 'cerulean'
lua54 'yes'
name 'Sentinel v1'
author 'FTW'
games { 'gta5' }

-- Load order: shared first, then client, then server
-- This ensures proper initialization sequence

convar_policy {
    read = { 'sentinel_license_key' }
}

dependencies {
    'oxmysql'
}

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/style.css',
    'ui/script.js',
    'ui/emd.html',
    'ui/emd.js',
}

-- CRITICAL: Shared scripts must load first
shared_scripts {
    'shared/sh_encryption.lua'
}

-- Client loads after shared
client_scripts {
    'client/cl_main.lua',
    'client/modules/cl_integrity.lua',
    'client/modules/cl_combat.lua',
    'client/modules/cl_misc.lua',
    'client/modules/cl_movement.lua',
    'client/modules/cl_vehicles.lua',
    'client/modules/cl_gui.lua',
    'client/modules/cl_scanner.lua',
    'client/cl_bans.lua',
    'client/modules/cl_upvalue_monitor.lua',
    'client/modules/cl_spectate.lua',
    'client/modules/cl_advanced.lua',
    'client/modules/cl_detections.lua',
    'client/modules/cl_heartbeat.lua',
    'client/modules/cl_resstop.lua',
    'client/modules/cl_signatures.lua',
    'client/modules/cl_emd.lua',
    'client/modules/cl_load_extra.lua',
    'client/modules/cl_errorhandler.lua'
}

-- Server loads last
server_scripts {
    'server/sv_license.lua',
    'server/sv_csprng_manager.lua',
    'server/sv_main.lua',
    'server/sv_bans.lua',
    'server/modules/sv_admin.lua',
    'server/modules/sv_combat.lua',
    'server/modules/sv_integrity.lua',
    'server/modules/sv_misc.lua',
    'server/modules/sv_movement.lua',
    'server/modules/sv_vehicles.lua',
    'server/modules/sv_gui.lua',
    'server/modules/sv_chat.lua',
    'server/modules/sv_scanner.lua',
    'server/modules/sv_servercheck.lua',
    'server/modules/sv_behavioral.lua',
    'server/modules/sv_timing.lua',
    'server/modules/sv_entity_audit.lua',
    'server/modules/sv_network.lua',
    'server/modules/sv_advanced.lua',
    'server/modules/sv_heartbeat.lua',
    'server/modules/sv_resstop.lua',
    'server/modules/sv_load_extra.lua',
    'server/modules/sv_errorhandler.lua'
}